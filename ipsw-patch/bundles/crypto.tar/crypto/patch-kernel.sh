#!/bin/bash
XPWNTOOL=./xpwntool
PATCHKERNEL=./patch-kernel-crypto
KERNEL=/System/Library/Caches/com.apple.kernelcaches/kernelcache.s5l8900x

if [ $# -ne 2 ]
then
	echo "Usage: $0 <iv> <key>"
	exit 1
fi

${XPWNTOOL} ${KERNEL} /tmp/a -iv $1 -k $2
${PATCHKERNEL} /tmp/a
${XPWNTOOL} /tmp/a /tmp/b -t ${KERNEL} -iv $1 -k $2
rm /tmp/a
cp ${KERNEL} /kernel.backup
cp /tmp/b ${KERNEL}
rm /tmp/b

